#!/usr/bin/env bash
# =============================================================================
# ПРОТОКОЛ ТЕСТИРОВАНИЯ стенда X-Forwarded-For
# Запускать ПОСЛЕ: docker-compose up -d
# =============================================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

pass() { echo -e "${GREEN}  ✓ PASS${NC}: $1"; }
fail() { echo -e "${RED}  ✗ FAIL${NC}: $1"; }
info() { echo -e "${CYAN}  ➜${NC} $1"; }
header() { echo -e "\n${BOLD}${YELLOW}══════════════════════════════════════════${NC}"; \
           echo -e "${BOLD}${YELLOW}  $1${NC}"; \
           echo -e "${BOLD}${YELLOW}══════════════════════════════════════════${NC}"; }

EDGE_DIRECT="http://localhost:8081"    # user -> nginx1 -> app
EDGE_CHAIN="http://localhost:8082"     # user -> nginx_chain -> nginx2 -> nginx3 -> app

# Ждём, пока стенд поднимется
echo -e "${BOLD}Ожидание готовности стенда...${NC}"
for i in $(seq 1 30); do
  curl -sf "$EDGE_DIRECT/" > /dev/null 2>&1 && break
  sleep 1; printf "."
done
echo ""

# =============================================================================
header "ТЕСТ 1: Прямой маршрут — user → nginx1 → app"
# =============================================================================
info "curl $EDGE_DIRECT/"
RESP=$(curl -s "$EDGE_DIRECT/")
XFF=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['X-Forwarded-For'])")
echo "  X-Forwarded-For: ${BOLD}$XFF${NC}"

# В XFF должен быть ровно 1 IP (IP пользователя, т.е. 127.0.0.1 или ::1)
COUNT=$(echo "$XFF" | tr ',' '\n' | grep -c '\.')
if [ "$COUNT" -eq 1 ]; then
  pass "Цепочка содержит 1 IP (пользователь → nginx1 → app)"
else
  fail "Ожидался 1 IP, получено: $XFF"
fi

# =============================================================================
header "ТЕСТ 2: Полная цепочка — user → nginx_chain → nginx2 → nginx3 → app"
# =============================================================================
info "curl $EDGE_CHAIN/"
RESP=$(curl -s "$EDGE_CHAIN/")
XFF=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['X-Forwarded-For'])")
echo "  X-Forwarded-For: ${BOLD}$XFF${NC}"

# В XFF должны быть 3 IP: пользователь, nginx_chain, nginx2
# (nginx3 — последний, он добавляет себя, итого 3 записи)
COUNT=$(echo "$XFF" | awk -F',' '{print NF}')
if [ "$COUNT" -ge 2 ]; then
  pass "Цепочка содержит $COUNT IP — все промежуточные узлы присутствуют"
else
  fail "Ожидалось ≥2 IP в цепочке, получено: $XFF"
fi

# =============================================================================
header "ТЕСТ 3: Защита от подделки XFF — злоумышленник подставляет фейковый IP"
# =============================================================================
FAKE_IP="1.3.3.7"
info "curl -H 'X-Forwarded-For: $FAKE_IP' $EDGE_DIRECT/"
RESP=$(curl -s -H "X-Forwarded-For: $FAKE_IP" "$EDGE_DIRECT/")
XFF=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['X-Forwarded-For'])")
echo "  X-Forwarded-For: ${BOLD}$XFF${NC}"

if echo "$XFF" | grep -q "$FAKE_IP"; then
  fail "УЯЗВИМОСТЬ: фейковый IP $FAKE_IP попал в X-Forwarded-For!"
else
  pass "Фейковый IP '$FAKE_IP' отброшен. В заголовке: $XFF"
fi

# =============================================================================
header "ТЕСТ 4: Подделка через цепочку — фейковый XFF через все nginx"
# =============================================================================
FAKE_IP="9.9.9.9"
info "curl -H 'X-Forwarded-For: $FAKE_IP' $EDGE_CHAIN/"
RESP=$(curl -s -H "X-Forwarded-For: $FAKE_IP" "$EDGE_CHAIN/")
XFF=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['X-Forwarded-For'])")
echo "  X-Forwarded-For: ${BOLD}$XFF${NC}"

if echo "$XFF" | grep -q "$FAKE_IP"; then
  fail "УЯЗВИМОСТЬ: фейковый IP $FAKE_IP дошёл до приложения через цепочку!"
else
  pass "Фейковый IP '$FAKE_IP' отброшен edge-прокси. В заголовке: $XFF"
fi

# =============================================================================
header "ТЕСТ 5: Проверка наличия реального IP пользователя (127.0.0.1)"
# =============================================================================
RESP=$(curl -s "$EDGE_CHAIN/")
XFF=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['X-Forwarded-For'])")
# При запросе с localhost клиентский IP — 127.0.0.1 или ::1
FIRST_IP=$(echo "$XFF" | awk -F',' '{print $1}' | tr -d ' ')
echo "  Первый IP в цепочке: ${BOLD}$FIRST_IP${NC}"

if [[ "$FIRST_IP" == "127.0.0.1" || "$FIRST_IP" == "::1" ]]; then
  pass "Первый IP — реальный адрес клиента ($FIRST_IP)"
else
  info "Первый IP: $FIRST_IP (в docker-сети это нормально — IP контейнера вместо 127.0.0.1)"
fi

# =============================================================================
echo -e "\n${BOLD}${GREEN}══════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  Тестирование завершено${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════${NC}\n"

echo -e "${CYAN}Полный вывод заголовков (цепочка):${NC}"
curl -s "$EDGE_CHAIN/" | python3 -m json.tool
