#!/usr/bin/env python3
"""Простое HTTP-приложение, выводящее заголовки запроса."""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json


class HeaderHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # подавляем стандартный лог

    def do_GET(self):
        xff = self.headers.get("X-Forwarded-For", "<не передан>")
        remote = self.client_address[0]

        body = {
            "remote_addr": remote,
            "X-Forwarded-For": xff,
            "all_headers": dict(self.headers),
        }
        payload = json.dumps(body, indent=2, ensure_ascii=False).encode()

        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", len(payload))
        self.end_headers()
        self.wfile.write(payload)

        print(f"[APP] remote={remote}  X-Forwarded-For: {xff}")


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 8000), HeaderHandler)
    print("App listening on :8000")
    server.serve_forever()
